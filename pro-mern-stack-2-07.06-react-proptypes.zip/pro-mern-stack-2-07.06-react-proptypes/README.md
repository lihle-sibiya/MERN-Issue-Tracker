# Pro MERN Stack - 2nd Edition

You are browsing the source code at the end of one of the sections in the book.

The project's README which contains the list of all chapters, sections
their sources and other useful information can be found in the
[master branch](https://github.com/vasansr/pro-mern-stack-2).
